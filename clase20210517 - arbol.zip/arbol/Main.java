package clase20210517.arbol;

public class Main {
    public static void main(String[] args) {
        Arbol palabras = new Arbol();
        palabras.addValor("Hola");
        palabras.addValor("Cómo");
        palabras.addValor("Estas");
        palabras.addValor("Perro");


        Arbol numeros = new Arbol();
        numeros.addValor(8);
        numeros.addValor(3);
        numeros.addValor(10);
        numeros.addValor(1);
        numeros.addValor(6);
        numeros.addValor(4);
        numeros.addValor(7);
        numeros.addValor(10);
        numeros.addValor(14);
        numeros.addValor(13);

        System.out.println(numeros.recorrido());
        //System.out.println(palabras);
    }
}
