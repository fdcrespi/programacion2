package clase20210517.filesystem;

import java.util.Locale;

public class CriterioContieneNombre implements Criterio{
    private String loQueBusco;

    public CriterioContieneNombre(String loQueBusco) {
        this.loQueBusco = loQueBusco.toLowerCase();
    }

    @Override
    public boolean cumple(ElementoFS elem) {
        return elem.getNombre().toLowerCase().contains(loQueBusco);
    }
}
