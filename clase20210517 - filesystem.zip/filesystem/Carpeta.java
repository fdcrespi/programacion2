package clase20210517.filesystem;

import java.util.ArrayList;

public class Carpeta extends ElementoFS {
    protected ArrayList<ElementoFS> elementos;

    public Carpeta(String nombre) {
        super(nombre);
        elementos = new ArrayList<>();
    }

    public void addElemento(ElementoFS nuevoElemento){
        if (!elementos.contains(nuevoElemento))
            elementos.add(nuevoElemento);
    }

    public int getTamanio(){
        int total = 0;
        for (ElementoFS elemento:elementos)
            total += elemento.getTamanio();
        return total;
    }

    public int cantidadArchivos(){
        int cantidadArchivos = 0;
        /**
         * NUNCA preguntar por el tipo de un objeto
         */
        for (ElementoFS elemento:elementos){
            cantidadArchivos += elemento.cantidadArchivos();
        }
        return cantidadArchivos;
    }

    @Override
    public boolean equals(Object obj) {
        try {
            Carpeta otraCarpeta = (Carpeta) obj;
            return this.getNombre().equals(otraCarpeta.getNombre());
        } catch (Exception e){
            return false;
        }
    }

    @Override
    public ArrayList<ElementoFS> buscar(Criterio criterio){
        ArrayList<ElementoFS> losQueCumplen = new ArrayList<>();
        if (criterio.cumple(this))
            losQueCumplen.add(this);
        for (ElementoFS elemento: elementos){
            losQueCumplen.addAll(elemento.buscar(criterio));
        }
        return losQueCumplen;
    }

    protected Carpeta duplicar(){
        return new Carpeta(this.getNombre());
    }

    @Override
    public ElementoFS getCopia() {
        Carpeta copia = duplicar();
        //Carpeta copia = new Carpeta(this.getNombre());
        for (ElementoFS e: elementos)
            copia.addElemento(e.getCopia());
        return copia;
    }

    @Override
    public ElementoFS getCopia(Criterio criterio) {
        //Intento duplicar los hijos y los guarda temporalmente
        //en un arraylist
        ArrayList<ElementoFS> copiaHijos = new ArrayList<>();
        for (ElementoFS e: elementos) {
            ElementoFS copiaElemento = e.getCopia();
            if (copiaElemento!=null)
                copiaHijos.add(copiaElemento);
        }
        //Me fijo si la carpeta cumple con el criterio
        //para ver si la duplico
        Carpeta copia = null;
        if (criterio.cumple(this))
            copia = duplicar();
        if (!copiaHijos.isEmpty()) {
            copia = duplicar();
            for (ElementoFS hijoDuplicado: copiaHijos)
                copia.addElemento(hijoDuplicado);
        }

        return copia;
    }


}
