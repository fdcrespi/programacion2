package clase20210517.filesystem;

import java.time.LocalDate;
import java.util.ArrayList;

public abstract class ElementoFS {
    protected String nombre;
    protected LocalDate fCreacion;
    protected LocalDate fModificacion;

    public ElementoFS(String nombre) {
        this.nombre = nombre;
        this.fCreacion = LocalDate.now();
        this.fModificacion = fCreacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public LocalDate getfCreacion() {
        return fCreacion;
    }

    public LocalDate getfModificacion() {
        return fModificacion;
    }

    protected void setfModificacion(LocalDate fModificacion) {
        this.fModificacion = fModificacion;
    }

    public abstract int getTamanio();
    public abstract int cantidadArchivos();
    public abstract ArrayList<ElementoFS> buscar(Criterio criterio);
    public abstract ElementoFS getCopia();
    public abstract ElementoFS getCopia(Criterio criterio);

    @Override
    public String toString() {
        return "ElementoFS{" +
                "nombre='" + nombre + '\'' +
                ", fCreacion=" + fCreacion +
                ", fModificacion=" + fModificacion +
                '}';
    }
}
