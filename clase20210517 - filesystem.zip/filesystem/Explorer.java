package clase20210517.filesystem;

import java.time.LocalDate;
import java.util.ArrayList;

public class Explorer {
    private Carpeta raiz;

    public Explorer(){
        raiz = new Carpeta("/");
    }


    public void addElemento(ElementoFS elem){
        raiz.addElemento(elem);
    }

    public ArrayList<ElementoFS> buscar(Criterio criterio){
        return raiz.buscar(criterio);
    }

    public static void main(String[] args) {
        Explorer explorer = new Explorer();
        Carpeta tudai = new Carpeta("TUDAI");
        Carpeta anio1 = new Carpeta("1er anio");
        Carpeta anio2 = new Carpeta("2do anio");
        Archivo calendario = new Archivo("Calendario", "pdf", 100);
        tudai.addElemento(anio1);
        tudai.addElemento(calendario);
        tudai.addElemento(anio2);

        explorer.addElemento(tudai);

        Carpeta prog2 = new Carpeta("Prog2");
        Archivo parcial = new Archivo("Parcial", "doc", 1500);
        Archivo recu = new Archivo("Recu", "pdf", 987);
        Archivo prefi = new Archivo("Prefi", "txt", 1050);

        prog2.addElemento(parcial);
        prog2.addElemento(recu);
        prog2.addElemento(prefi);

        anio1.addElemento(prog2);

        parcial.setfModificacion(LocalDate.of(2020, 1, 15));

        Criterio contieneAnio = new CriterioContieneNombre("2");
        Criterio antesDe = new CriterioModificadoAntesDe(LocalDate.of(2020, 2, 10));
        System.out.println(explorer.buscar(antesDe));
    }
}
