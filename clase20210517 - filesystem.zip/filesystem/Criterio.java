package clase20210517.filesystem;

public interface Criterio {
    boolean cumple(ElementoFS elem);
}
