package clase20210517.filesystem;

import java.time.LocalDate;

public class CriterioCreadoAntesDe implements Criterio{
    LocalDate fechaLimite;

    public CriterioCreadoAntesDe(LocalDate fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    @Override
    public boolean cumple(ElementoFS elem) {
        return elem.getfCreacion().compareTo(fechaLimite) < 0;
    }
}
