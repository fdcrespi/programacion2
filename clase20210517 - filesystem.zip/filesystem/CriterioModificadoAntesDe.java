package clase20210517.filesystem;

import java.time.LocalDate;

public class CriterioModificadoAntesDe implements Criterio{
    LocalDate fechaLimite;

    public CriterioModificadoAntesDe(LocalDate fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    @Override
    public boolean cumple(ElementoFS elem) {
        return elem.getfModificacion().compareTo(fechaLimite) < 0;
    }
}
