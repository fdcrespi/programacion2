package clase20210517.filesystem;

import java.util.ArrayList;

public class Comprimido extends Carpeta {

    private double factorCompresion;

    public Comprimido(String nombre, double factorCompresion) {
        super(nombre);
        this.factorCompresion = factorCompresion;
    }

    @Override
    public int getTamanio() {
        return (int) (super.getTamanio()*factorCompresion);
    }

    @Override
    public int cantidadArchivos() {
        return 1;
    }

    @Override
    public ArrayList<ElementoFS> buscar(Criterio criterio){
        ArrayList<ElementoFS> losQueCumplen = new ArrayList<>();
        for (ElementoFS elemento: elementos){
            if (!elemento.buscar(criterio).isEmpty()) {
                losQueCumplen.add(this);
                return losQueCumplen;
            }
        }
        return losQueCumplen;
    }

    @Override
    public Carpeta duplicar() {
        return new Comprimido(this.getNombre(), this.factorCompresion);
    }

}
