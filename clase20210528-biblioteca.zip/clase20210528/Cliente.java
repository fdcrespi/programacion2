package clase20210528;

import clase20210528.criterios.Criterio;

import java.util.ArrayList;

public class Cliente {
    private String nombre;
    private Criterio preferencias;

    //preferecias
    /*private boolean leImportaAireLibre;
    private String leImportaRubro;
    private double metrosMinimos;
    private ArrayList<String> protocolosQueLeImportan;*/

    public Cliente(String nombre, Criterio preferencias) {
        this.nombre = nombre;
        this.preferencias = preferencias;
    }

    public boolean puedeAsistir(Comercio comercio){
        return preferencias.cumple(comercio);
    }
}
