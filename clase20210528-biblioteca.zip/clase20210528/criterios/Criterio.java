package clase20210528.criterios;

import clase20210528.Comercio;

public interface Criterio {
    boolean cumple(Comercio c);
}
