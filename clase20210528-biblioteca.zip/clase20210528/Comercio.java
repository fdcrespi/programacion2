package clase20210528;

import java.util.ArrayList;

public class Comercio {
    private String nombre;
    private String rubro;
    private double metros2;
    private boolean disponeAireLibre;
    private ArrayList<String> protocolos;

    public Comercio(String nombre, String rubro, double metros2, boolean disponeAireLibre) {
        this.nombre = nombre;
        this.rubro = rubro;
        this.metros2 = metros2;
        this.disponeAireLibre = disponeAireLibre;
        this.protocolos = new ArrayList<>();
    }

    public void addProtocolo(String protocolo){
        this.protocolos.add(protocolo);
    }

    public ArrayList<String> getProtocolos(){
        return new ArrayList<>(protocolos);
    }

    public boolean implementaProtocolo(String protocolo){
        return protocolos.contains(protocolo);
    }

    //Getters y setters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRubro() {
        return rubro;
    }

    public void setRubro(String rubro) {
        this.rubro = rubro;
    }

    public double getMetros2() {
        return metros2;
    }

    public void setMetros2(double metros2) {
        this.metros2 = metros2;
    }

    public boolean isDisponeAireLibre() {
        return disponeAireLibre;
    }

    public void setDisponeAireLibre(boolean disponeAireLibre) {
        this.disponeAireLibre = disponeAireLibre;
    }
}
