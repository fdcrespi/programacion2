package clase20210528.biblioteca;

import java.util.ArrayList;
import java.util.Comparator;

public class Biblioteca {
    private ArrayList<Libro> libros;
    private Estrategia estrategia;

    public Biblioteca() {
        libros = new ArrayList<>();
    }

    public void addLibro(Libro libro){
        libros.add(libro);
    }

    public Libro prestar(String titulo){
        ArrayList<Libro> librosTitulo = new ArrayList<>();
        for (Libro libro:libros)
            if (libro.getTitulo().equals(titulo))
                librosTitulo.add(libro);
        return estrategia.elegi(librosTitulo);
    }

    public void cambiarEstrategia(Estrategia nueva){
        estrategia = nueva;
    }
}
