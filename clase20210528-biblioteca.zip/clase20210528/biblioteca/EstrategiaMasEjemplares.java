package clase20210528.biblioteca;

import java.util.List;

public class EstrategiaMasEjemplares extends Estrategia{

    @Override
    public boolean comparar(Libro l1, Libro l2) {
        return l1.getCantEjemplares() > l2.getCantEjemplares();
    }
}
