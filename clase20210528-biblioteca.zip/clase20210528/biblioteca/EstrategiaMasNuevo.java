package clase20210528.biblioteca;

import java.time.LocalDate;
import java.util.List;

public class EstrategiaMasNuevo extends Estrategia{
    @Override
    public boolean comparar(Libro l1, Libro l2) {
        return l1.getFechaCompra().compareTo(l2.getFechaCompra()) > 0;
    }
}
