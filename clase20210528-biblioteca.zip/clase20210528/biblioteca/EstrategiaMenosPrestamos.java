package clase20210528.biblioteca;

import java.util.List;

public class EstrategiaMenosPrestamos extends Estrategia{
    @Override
    public boolean comparar(Libro l1, Libro l2) {
        return l1.getCantPrestamos() < l2.getCantPrestamos();
    }
}
