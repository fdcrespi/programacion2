package clase20210528.biblioteca;

import java.time.LocalDate;

public class Libro {
    private String nombre;
    private int cantEjemplares;
    private LocalDate fechaCompra;
    private int cantPrestamos;

    public Libro(String nombre, int cantEjemplares, LocalDate fechaCompra, int cantPrestamos) {
        this.nombre = nombre;
        this.cantEjemplares = cantEjemplares;
        this.fechaCompra = fechaCompra;
        this.cantPrestamos = cantPrestamos;
    }

    public String getTitulo() {
        return nombre;
    }

    public int getCantEjemplares() {
        return cantEjemplares;
    }

    public LocalDate getFechaCompra() {
        return fechaCompra;
    }

    public int getCantPrestamos() {
        return cantPrestamos;
    }
}
