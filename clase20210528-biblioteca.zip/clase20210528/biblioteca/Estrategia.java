package clase20210528.biblioteca;

import java.util.List;

public abstract class Estrategia {
    public Libro elegi(List<Libro> libros){
        if (libros.isEmpty())
            return null;
        Libro masNuevo = libros.get(0);
        for (int i =1; i<libros.size(); i++)
            if (this.comparar(libros.get(i), masNuevo))
                masNuevo = libros.get(i);
        return masNuevo;
    }

    public abstract boolean comparar(Libro l1, Libro l2);
}
