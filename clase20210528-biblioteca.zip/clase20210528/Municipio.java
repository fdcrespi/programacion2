package clase20210528;

import clase20210528.criterios.Criterio;

import java.util.ArrayList;

public class Municipio {
    private String nombre;
    private ArrayList<Comercio> comercios;

    public Municipio(String nombre) {
        this.nombre = nombre;
        this.comercios = new ArrayList<>();
    }

    public void addComercio(Comercio comercio){
        comercios.add(comercio);
    }

    public ArrayList<Comercio> puedeAsistir(Cliente cliente){
        ArrayList<Comercio> losQueCumplen = new ArrayList<>();
        for(Comercio comercio:comercios){
            if (cliente.puedeAsistir(comercio))
                losQueCumplen.add(comercio);
        }
        return losQueCumplen;
    }

    public boolean puedeAsistir(Cliente cliente, Comercio comercio){
        return cliente.puedeAsistir(comercio);
    }

    public ArrayList<Comercio> buscar(Criterio criterio){
        ArrayList<Comercio> losQueCumplen = new ArrayList<>();
        for(Comercio comercio:comercios){
            if (criterio.cumple(comercio))
                losQueCumplen.add(comercio);
        }
        return losQueCumplen;
    }


}
