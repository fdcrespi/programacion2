package clase20210528.biblioteca2;

import java.util.Comparator;

public class ComparadorMasNuevo implements Comparator<Libro> {
    @Override
    public int compare(Libro l1, Libro l2) {
        return l1.getFechaCompra().compareTo(l2.getFechaCompra());
    }
}
