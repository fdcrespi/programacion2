package clase20210528.biblioteca2;

import java.util.Comparator;

public class ComparadorMasEjemplares implements Comparator<Libro> {
    @Override
    public int compare(Libro l1, Libro l2) {
        return l1.getCantEjemplares()-(l2.getCantEjemplares());
    }
}
