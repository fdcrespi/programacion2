package clase20210528.biblioteca2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Biblioteca {
    private ArrayList<Libro> libros;
    private Comparator estrategia;

    public Biblioteca() {
        libros = new ArrayList<>();
    }

    public void addLibro(Libro libro){
        libros.add(libro);
    }

    public Libro prestar(String titulo){
        ArrayList<Libro> librosTitulo = new ArrayList<>();
        for (Libro libro:libros)
            if (libro.getTitulo().equals(titulo))
                librosTitulo.add(libro);

        if (librosTitulo.isEmpty())
            return null;
        else {
            Collections.sort(librosTitulo, estrategia);
            return librosTitulo.get(0);
        }
    }

    public void cambiarEstrategia(Comparator nueva){
        estrategia = nueva;
    }
}
