package clase20210510;

public class Comprimido extends Carpeta{

    private double factorCompresion;

    public Comprimido(String nombre, double factorCompresion) {
        super(nombre);
        this.factorCompresion = factorCompresion;
    }

    @Override
    public int getTamanio() {
        return (int) (super.getTamanio()*factorCompresion);
    }

    @Override
    public int cantidadArchivos() {
        return 1;
    }
}
