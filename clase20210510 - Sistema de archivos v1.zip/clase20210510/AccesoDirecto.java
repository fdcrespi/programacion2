package clase20210510;

public class AccesoDirecto extends ElementoFS{

    private ElementoFS apuntado;
    public static final String PREFIJO = "Acceso directo a ";
    public static final int TAMANIO = 1;

    public AccesoDirecto(ElementoFS apuntado){
        super(PREFIJO+apuntado.getNombre());
        this.apuntado = apuntado;
    }

    //No decia el enunciado, pero mantenemos consistencia
    //entre el nombre del acceso directo y el nombre del archivo
    @Override
    public String getNombre() {
        return PREFIJO+apuntado.getNombre();
    }

    @Override
    public int getTamanio() {
        return TAMANIO;
    }

    @Override
    public int cantidadArchivos() {
        return 0;
    }
}
