package clase20210510;

import java.util.ArrayList;

public class Carpeta extends ElementoFS{
    private ArrayList<ElementoFS> elementos;

    public Carpeta(String nombre) {
        super(nombre);
        elementos = new ArrayList<>();
    }

    public void addElemento(ElementoFS nuevoElemento){
        if (!elementos.contains(nuevoElemento))
            elementos.add(nuevoElemento);
    }

    public int getTamanio(){
        int total = 0;
        for (ElementoFS elemento:elementos)
            total += elemento.getTamanio();
        return total;
    }

    public int cantidadArchivos(){
        int cantidadArchivos = 0;
        /**
         * NUNCA preguntar por el tipo de un objeto
         */
        for (ElementoFS elemento:elementos){
            cantidadArchivos += elemento.cantidadArchivos();
        }
        return cantidadArchivos;
    }

    @Override
    public boolean equals(Object obj) {
        try {
            Carpeta otraCarpeta = (Carpeta) obj;
            return this.getNombre().equals(otraCarpeta.getNombre());
        } catch (Exception e){
            return false;
        }
    }
}
