package clase20210528.criterios;

import clase20210528.Comercio;

public class CriterioNot implements Criterio{
    Criterio criterio;

    public CriterioNot(Criterio criterio) {
        this.criterio = criterio;
    }

    @Override
    public boolean cumple(Comercio c) {
        return !criterio.cumple(c);
    }
}
