package clase20210528.criterios;

import clase20210528.Comercio;

public class CriterioAireLire implements Criterio{
    private boolean quiereONo;

    public CriterioAireLire(boolean quiereONo) {
        this.quiereONo = quiereONo;
    }

    @Override
    public boolean cumple(Comercio c) {
        return c.isDisponeAireLibre() == quiereONo;
    }
}
