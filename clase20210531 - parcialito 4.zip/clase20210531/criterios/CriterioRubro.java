package clase20210528.criterios;

import clase20210528.Comercio;

public class CriterioRubro implements Criterio{

    private String rubro;

    public CriterioRubro(String rubro) {
        this.rubro = rubro;
    }

    @Override
    public boolean cumple(Comercio c) {
        return c.getRubro().equals(rubro);
    }
}
