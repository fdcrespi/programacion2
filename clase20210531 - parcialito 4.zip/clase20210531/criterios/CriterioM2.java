package clase20210528.criterios;

import clase20210528.Comercio;

public class CriterioM2 implements Criterio{
    private double m2;

    public CriterioM2(double m2) {
        this.m2 = m2;
    }

    @Override
    public boolean cumple(Comercio c) {
        return c.getMetros2() > m2;
    }
}
