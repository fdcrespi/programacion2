package clase20210528.criterios;

import clase20210528.Comercio;

import java.util.ArrayList;

public class CriterioProtocolo implements Criterio{
    private ArrayList<String> protocolos;

    public CriterioProtocolo(ArrayList<String> protocolos) {
        this.protocolos = new ArrayList<>(protocolos);
    }

    @Override
    public boolean cumple(Comercio c) {
        for (String p:protocolos)
            if (!c.implementaProtocolo(p))
                return false;
        return true;
    }
}
