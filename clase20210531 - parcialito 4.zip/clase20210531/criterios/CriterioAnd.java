package clase20210528.criterios;

import clase20210528.Comercio;

public class CriterioAnd implements Criterio{
    Criterio criterio1, criterio2;

    public CriterioAnd(Criterio criterio1, Criterio criterio2) {
        this.criterio1 = criterio1;
        this.criterio2 = criterio2;
    }

    @Override
    public boolean cumple(Comercio c) {
        return criterio1.cumple(c) && criterio2.cumple(c);
    }
}
