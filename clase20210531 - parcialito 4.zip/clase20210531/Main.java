package clase20210528;

import clase20210528.criterios.*;

public class Main {

    public static void main(String[] args) {
        Municipio tresarroyos = new Municipio("Tres Arroyos");
        Comercio c1 = new Comercio("Patito", "Limpieza", 50, false);
        Comercio c2 = new Comercio("El balde", "Limpieza", 150, true);
        Comercio c3 = new Comercio("El ombu", "Parrilla", 250, true);

        Criterio aireLibreYLimpieza = new CriterioAnd(
                new CriterioAireLire(true),
                new CriterioRubro("Limpieza")
        );
        Criterio aireLibreYLimpiezaYMasDe25 = new CriterioAnd(
                aireLibreYLimpieza,
                new CriterioM2(25)
        );
        Cliente juan = new Cliente("Juan", aireLibreYLimpiezaYMasDe25);

        tresarroyos.addComercio(c1);
        tresarroyos.addComercio(c2);
        tresarroyos.addComercio(c3);

        System.out.println("Juan puede asistir a los siguientes comercios: ");
        System.out.println(tresarroyos.puedeAsistir(juan));

        System.out.println("Los comercios de rubro limpieza son los siguientes");

        CriterioRubro comerciosRubroLimpieza = new CriterioRubro("Limpieza");
        System.out.println(tresarroyos.buscar(comerciosRubroLimpieza));

        Cliente lucas = new Cliente("Lucas", new CriterioAireLire(true));
        System.out.println("Lucas puede asistir a los siguientes comercios: ");
        System.out.println(tresarroyos.puedeAsistir(lucas));

    }
}
