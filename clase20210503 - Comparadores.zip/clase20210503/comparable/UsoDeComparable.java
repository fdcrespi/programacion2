package clase20210503.comparable;

import clase20210503.comparable.comparadores.ComparadorEmpleado;
import clase20210503.comparable.comparadores.ComparadorEmpleadoApellido;
import clase20210503.comparable.comparadores.ComparadorEmpleadoNombre;
import clase20210503.comparable.comparadores.ComparadorEmpleadoSueldo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UsoDeComparable {


    public static void main(String[] args) {
        List<Dinosaurio> dinosaurios = new ArrayList<>();
        Dinosaurio tRex = new Dinosaurio(2000, "T-rex", "carnivoro");
        Dinosaurio triceratops = new Dinosaurio(1000, "Triceratops", "hervivoro");
        Dinosaurio plesiosaurio = new Dinosaurio(1500, "Plesiosaurio", "hervivoro");

        dinosaurios.add(tRex);
        dinosaurios.add(triceratops);
        dinosaurios.add(plesiosaurio);

        Collections.sort(dinosaurios, Collections.reverseOrder());

        for(Dinosaurio d:dinosaurios)
            System.out.println(d);


        Empleado e1 = new Empleado("Blas", "Garcia", 45000);
        Empleado e2 = new Empleado("Juan", "Perez", 12000);
        Empleado e3 = new Empleado("Andrea", "Garcia", 50000);

        ArrayList<Empleado> empleados = new ArrayList<>();
        empleados.add(e1);
        empleados.add(e2);
        empleados.add(e3);

        ComparadorEmpleadoSueldo compEmpSueldo = new ComparadorEmpleadoSueldo();
        Collections.sort(empleados, compEmpSueldo);

        for(Empleado e:empleados)
            System.out.println(e);

        Collections.sort(empleados, new ComparadorEmpleadoNombre());

        Collections.sort(empleados, new ComparadorEmpleadoApellido(
                new ComparadorEmpleadoNombre(
                        new ComparadorEmpleadoSueldo())));
        System.out.println("Ordenados por los 3 atributos");
        System.out.println(empleados);

        ComparadorEmpleado apellidoDesc = (ComparadorEmpleado) new ComparadorEmpleadoApellido().reversed();
        Collections.sort(empleados, new ComparadorEmpleadoSueldo(apellidoDesc));
        System.out.println("Ordenados por sueldo y apellido");
        System.out.println(empleados);
        //Forma de copiar una lista 1
        ArrayList<Empleado> copia = new ArrayList<>(empleados);

        //Forma de copiar una lista 2
        ArrayList<Empleado> copia2 = new ArrayList<>();
        copia2.addAll(empleados);

        //System.out.println(empleados);
    }

}
