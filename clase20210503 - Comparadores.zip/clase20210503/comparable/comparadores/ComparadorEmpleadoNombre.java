package clase20210503.comparable.comparadores;

import clase20210503.comparable.Empleado;

import java.util.Comparator;

public class ComparadorEmpleadoNombre extends ComparadorEmpleado {

    public ComparadorEmpleadoNombre() {
        super();
    }
    public ComparadorEmpleadoNombre(ComparadorEmpleado siguiente) {
        super(siguiente);
    }

    @Override
    public int comparar(Empleado o1, Empleado o2) {
        return o1.getNombre().compareTo(o2.getNombre());
    }
}
