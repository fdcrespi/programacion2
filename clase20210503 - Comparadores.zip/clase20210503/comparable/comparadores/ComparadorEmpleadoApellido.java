package clase20210503.comparable.comparadores;

import clase20210503.comparable.Empleado;

import java.util.Comparator;

public class ComparadorEmpleadoApellido extends ComparadorEmpleado {

    public ComparadorEmpleadoApellido() {
        super();
    }
    public ComparadorEmpleadoApellido(ComparadorEmpleado siguiente) {
        super(siguiente);
    }

    @Override
    public int comparar(Empleado o1, Empleado o2) {
       return o1.getApellido().compareTo(o2.getApellido());
    }
}
