package clase20210503.comparable.comparadores;

import clase20210503.comparable.Empleado;

import java.util.Comparator;

public abstract class ComparadorEmpleado implements Comparator<Empleado> {
    private ComparadorEmpleado comparadorSiguiente;

    public ComparadorEmpleado (){
        this.comparadorSiguiente = null;
    }

    public ComparadorEmpleado (ComparadorEmpleado siguiente){
        this.comparadorSiguiente = siguiente;
    }

    public abstract int comparar(Empleado o1, Empleado o2);

    @Override
    public int compare(Empleado o1, Empleado o2) {
        /**
         *  ESTO ES UN METODO TEMPLATE (método abstracto que en su implementación invoca a un método abstracto)
         */
        int resultado = comparar(o1, o2); //DECIDEN LOS HIJOS
        if (resultado == 0) {
            if (comparadorSiguiente!=null)
                return comparadorSiguiente.compare(o1, o2);
            else
                return 0;
        }
        else
            return resultado;
    }
}
