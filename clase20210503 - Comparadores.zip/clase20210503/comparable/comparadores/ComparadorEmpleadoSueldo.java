package clase20210503.comparable.comparadores;

import clase20210503.comparable.Empleado;

import java.util.Comparator;

public class ComparadorEmpleadoSueldo extends ComparadorEmpleado {

    public ComparadorEmpleadoSueldo(){
        super();
    }

    public ComparadorEmpleadoSueldo(ComparadorEmpleado siguiente) {
        super(siguiente);
    }

    @Override
    public int comparar(Empleado o1, Empleado o2) {
        return (int) o1.getSueldo() - (int) o2.getSueldo();
    }
}
