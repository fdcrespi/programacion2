package clase20210503.comparable;

public class Empleado implements Comparable<Empleado>{
    private String nombre;
    private String apellido;
    private double sueldo;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public Empleado(String nombre, String apellido, double sueldo) {
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.apellido = apellido;
    }

    /**
     * Los empleados se ordenan por sueldo de menor a mayor
     */
    @Override
    public int compareTo(Empleado o) {
        if (this.getSueldo() < o.getSueldo())
            return -10;
        else if (this.getSueldo() > o.getSueldo())
            return 5647;
        else return 0;
        /*int comp = this.getApellido().compareTo(o.getApellido());
        if (comp == 0)
            return this.getNombre().compareTo(o.getNombre());
        return comp;*/
    }

    public String getApellido() {
        return apellido;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "nombre='" + nombre + '\'' +
                "apellido='" + apellido + '\'' +
                ", sueldo=" + sueldo +
                '}';
    }
}
