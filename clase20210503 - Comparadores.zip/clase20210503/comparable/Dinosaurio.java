package clase20210503.comparable;

public class Dinosaurio implements Comparable<Dinosaurio>{
    private double peso;
    private String nombre;
    private String queCome;

    public Dinosaurio(double peso, String nombre, String queCome) {
        this.peso = peso;
        this.nombre = nombre;
        this.queCome = queCome;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getQueCome() {
        return queCome;
    }

    public void setQueCome(String queCome) {
        this.queCome = queCome;
    }

    /**
     * Comparable retorna
     * 0 si los dos objetos son iguales
     * < 0 si this < otroObjeto
     * > 0 si this > otroObjeto
     */
    @Override
    public int compareTo(Dinosaurio otro) {
        return  this.getNombre().compareTo(otro.getNombre()) ;
    }

    @Override
    public String toString() {
        return "Dinosaurio{" +
                "peso=" + peso +
                ", nombre='" + nombre + '\'' +
                ", queCome='" + queCome + '\'' +
                '}';
    }
}
