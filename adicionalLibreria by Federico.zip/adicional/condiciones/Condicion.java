package adicional.condiciones;

import adicional.Cliente;

public interface Condicion {
    boolean cumple(Cliente cliente);
}
